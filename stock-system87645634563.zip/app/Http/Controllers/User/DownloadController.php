<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Download;
use App\Models\Service;
use App\Models\CachedFile;
use App\Services\DownloadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class DownloadController extends Controller
{
    private $downloadService;

    public function __construct(DownloadService $downloadService)
    {
        $this->downloadService = $downloadService;
    }

    public function index()
    {
        $downloads = Auth::user()
            ->downloads()
            ->with('service')
            ->latest()
            ->paginate(10);

        return view('downloads.index', compact('downloads'));
    }

    public function create()
    {
        $services = Service::active()->get();
        return view('downloads.create', compact('services'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();
        
        if (!$user->hasActiveSubscription()) {
            return redirect()->back()->with('error', 'Your subscription has expired. Please renew to continue downloading.');
        }

        Log::info('Received download request:', ['urls' => $request->urls]);

        $request->validate([
            'urls' => ['required', 'array', 'min:1'],
            'urls.*.url' => ['required', 'url'],
            'urls.*.service_id' => ['required', 'exists:services,id'],
            'urls.*.file_id' => ['required', 'string'],
        ]);

        $urls = collect($request->urls);
        $totalPoints = 0;
        $downloads = [];

        Log::info('Processing URLs:', ['count' => $urls->count()]);

        // Calculate total points needed
        foreach ($urls as $urlData) {
            $service = Service::find($urlData['service_id']);
            if (!$service) {
                Log::error('Service not found:', ['service_id' => $urlData['service_id']]);
                return back()->withInput()->withErrors(['error' => 'Service not found']);
            }
            $totalPoints += $service->points_cost;
        }

        Log::info('Total points needed:', ['points' => $totalPoints]);

        // Check if user has enough points
        if ($user->points < $totalPoints) {
            Log::warning('Insufficient points:', [
                'required' => $totalPoints,
                'available' => $user->points
            ]);
            return back()
                ->withInput()
                ->withErrors(['error' => "You don't have enough points. Required: {$totalPoints}, Available: {$user->points}"]);
        }

        try {
            DB::beginTransaction();

            Log::info('Creating downloads...');

            // Create downloads
            foreach ($urls as $urlData) {
                $service = Service::find($urlData['service_id']);
                
                Log::info('Creating download:', [
                    'url' => $urlData['url'],
                    'service' => $service->name,
                    'file_id' => $urlData['file_id']
                ]);

                $download = Download::create([
                    'user_id' => $user->id,
                    'service_id' => $service->id,
                    'original_url' => $urlData['url'],
                    'file_id' => $urlData['file_id'],
                    'points_spent' => $service->points_cost,
                    'status' => Download::STATUS_PROCESSING,
                ]);

                $downloads[] = $download;
            }

            // Deduct points from user
            $user->points -= $totalPoints;
            $user->save();

            Log::info('Downloads created successfully:', [
                'count' => count($downloads),
                'points_deducted' => $totalPoints
            ]);

            DB::commit();

            // If only one download, process it immediately
            if (count($downloads) === 1) {
                try {
                    $this->downloadService->processDownload(
                        $downloads[0]->original_url,
                        $downloads[0]->service_id,
                        $downloads[0]->file_id
                    );
                    $downloads[0]->status = Download::STATUS_COMPLETED;
                    $downloads[0]->save();
                    
                    return redirect()
                        ->route('downloads.index')
                        ->with('success', 'Download completed successfully');
                } catch (\Exception $e) {
                    Log::error('Download processing failed:', [
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);
                    $downloads[0]->status = Download::STATUS_FAILED;
                    $downloads[0]->error_message = $e->getMessage();
                    $downloads[0]->save();
                    
                    return back()->withErrors(['error' => 'Failed to process download: ' . $e->getMessage()]);
                }
            }

            // If multiple downloads, redirect to index
            return redirect()
                ->route('downloads.index')
                ->with('success', count($downloads) . ' download requests created successfully');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating downloads:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()
                ->withInput()
                ->withErrors(['error' => 'An error occurred while creating the download requests: ' . $e->getMessage()]);
        }
    }

    public function show(Download $download)
    {
        if (! Gate::allows('view', $download)) {
            abort(403);
        }

        if ($download->status === Download::STATUS_PROCESSING) {
            try {
                $this->downloadService->processDownload(
                    $download->original_url,
                    $download->service_id,
                    $download->file_id
                );
                $download->status = Download::STATUS_COMPLETED;
                $download->save();
                
                return redirect()
                    ->route('downloads.index')
                    ->with('success', 'Download completed successfully');
            } catch (\Exception $e) {
                Log::error('Download processing failed:', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                $download->status = Download::STATUS_FAILED;
                $download->error_message = $e->getMessage();
                $download->save();
                
                return back()->withErrors(['error' => 'Failed to process download: ' . $e->getMessage()]);
            }
        }

        return view('downloads.show', compact('download'));
    }

    public function download(Download $download)
    {
        if (! Gate::allows('view', $download)) {
            abort(403);
        }

        // Find cached file
        $cachedFile = CachedFile::where('service_id', $download->service_id)
            ->where('file_id', $download->file_id)
            ->first();

        if (!$cachedFile) {
            Log::error('Cached file not found for download:', [
                'download_id' => $download->id,
                'service_id' => $download->service_id,
                'file_id' => $download->file_id
            ]);
            return back()->withErrors(['error' => 'File not found in storage']);
        }

        if (!Storage::exists($cachedFile->path)) {
            Log::error('File missing from storage:', [
                'cached_file_id' => $cachedFile->id,
                'path' => $cachedFile->path
            ]);
            return back()->withErrors(['error' => 'File not found in storage']);
        }

        Log::info('Serving download:', [
            'download_id' => $download->id,
            'cached_file_id' => $cachedFile->id,
            'path' => $cachedFile->path
        ]);

        $cachedFile->updateLastAccessed();
        
        return Storage::download(
            $cachedFile->path, 
            $cachedFile->original_filename
        );
    }
}
