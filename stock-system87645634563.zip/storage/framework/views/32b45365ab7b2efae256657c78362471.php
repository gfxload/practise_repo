<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
$classes = match($status) {
    'completed', 'active' => 'bg-green-100 text-green-800',
    'failed', 'inactive' => 'bg-red-100 text-red-800',
    'pending', 'processing' => 'bg-yellow-100 text-yellow-800',
    default => 'bg-gray-100 text-gray-800'
};
?>

<span <?php echo e($attributes->merge(['class' => 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full ' . $classes])); ?>>
    <?php echo e(ucfirst($status)); ?>

</span>
<?php /**PATH I:\Subscription-management\sys\stock-system\resources\views/components/status-badge.blade.php ENDPATH**/ ?>