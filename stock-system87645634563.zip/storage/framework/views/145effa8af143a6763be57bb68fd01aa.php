<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active', 'icon' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active', 'icon' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
$classes = ($active ?? false)
    ? 'group flex items-center px-3 py-2 text-base font-medium rounded-md text-indigo-600 bg-indigo-50'
    : 'group flex items-center px-3 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900';

$iconClasses = ($active ?? false)
    ? 'mr-4 flex-shrink-0 h-6 w-6 text-indigo-600'
    : 'mr-4 flex-shrink-0 h-6 w-6 text-gray-400 group-hover:text-gray-500';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php if(isset($icon)): ?>
        <div class="<?php echo e($iconClasses); ?>">
            <?php echo e($icon); ?>

        </div>
    <?php endif; ?>
    <?php echo e($slot); ?>

</a>
<?php /**PATH I:\Subscription-management\sys\stock-system\resources\views/components/responsive-nav-link.blade.php ENDPATH**/ ?>