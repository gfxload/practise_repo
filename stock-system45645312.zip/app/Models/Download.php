<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User;
use App\Models\Service;
use App\Models\PointTransaction;

class Download extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'service_id',
        'original_url',
        'file_id',
        'points_spent',
        'local_path',
        'status',
        'error_message'
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_PROCESSING = 'processing';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    public function pointTransaction()
    {
        return $this->hasOne(PointTransaction::class);
    }

    public function updateStatus(string $status, ?string $errorMessage = null)
    {
        $this->status = $status;
        $this->error_message = $errorMessage;
        $this->save();
    }

    public function markAsProcessing()
    {
        $this->updateStatus(self::STATUS_PROCESSING);
    }

    public function markAsCompleted()
    {
        $this->updateStatus(self::STATUS_COMPLETED);
    }

    public function markAsFailed(string $errorMessage)
    {
        $this->updateStatus(self::STATUS_FAILED, $errorMessage);
    }
}
