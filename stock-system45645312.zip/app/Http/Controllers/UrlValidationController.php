<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class UrlValidationController extends Controller
{
    public function validateUrl(Request $request)
    {
        $request->validate([
            'url' => ['required', 'url']
        ]);

        $url = $request->input('url');
        $result = Service::findServiceAndExtractId($url);

        if (!$result) {
            return response()->json([
                'success' => false,
                'message' => 'عذراً، هذا الرابط غير مدعوم. يرجى التأكد من أنه رابط صحيح من الخدمات المدعومة.',
            ], 400);
        }

        if ($result['file_id'] === null) {
            return response()->json([
                'success' => false,
                'message' => 'لم نتمكن من استخراج معرف الملف من الرابط. يرجى التأكد من صحة الرابط.',
            ], 400);
        }

        // Log successful validation
        Log::info('URL validated successfully', [
            'url' => $url,
            'service' => $result['service']->name,
            'file_id' => $result['file_id']
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'service' => [
                    'id' => $result['service']->id,
                    'name' => $result['service']->name,
                    'points_cost' => $result['service']->points_cost,
                ],
                'file_id' => $result['file_id'],
            ]
        ]);
    }
}
