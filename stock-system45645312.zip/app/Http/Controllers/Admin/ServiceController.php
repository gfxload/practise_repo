<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ServiceController extends Controller
{
    public function index()
    {
        $services = Service::latest()->paginate(10);
        return view('admin.services.index', compact('services'));
    }

    public function create()
    {
        return view('admin.services.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'points_cost' => ['required', 'integer', 'min:0'],
            'image' => ['nullable', 'image', 'max:2048'],
            'url_pattern' => ['nullable', 'string', 'max:255'],
            'file_id_pattern' => ['nullable', 'string', 'max:255'],
            'expected_url_format' => ['nullable', 'string', 'max:255'],
        ]);

        try {
            // Validate regex patterns if provided
            if (!empty($validated['url_pattern'])) {
                $this->validateRegexPattern($validated['url_pattern']);
            }
            if (!empty($validated['file_id_pattern'])) {
                $this->validateRegexPattern($validated['file_id_pattern']);
            }

            $data = [
                'name' => $validated['name'],
                'description' => $validated['description'],
                'points_cost' => $validated['points_cost'],
                'is_active' => $request->has('is_active'),
                'url_pattern' => $validated['url_pattern'],
                'file_id_pattern' => $validated['file_id_pattern'],
                'expected_url_format' => $validated['expected_url_format'],
            ];

            if ($request->hasFile('image')) {
                $data['image_path'] = $request->file('image')->store('services', 'public');
            }

            $service = Service::create($data);

            return redirect()
                ->route('admin.services.index')
                ->with('success', 'Service created successfully');
        } catch (\Exception $e) {
            Log::error('Error creating service:', ['error' => $e->getMessage()]);
            return back()
                ->withInput()
                ->withErrors(['error' => 'Failed to create service: ' . $e->getMessage()]);
        }
    }

    public function edit(Service $service)
    {
        return view('admin.services.edit', compact('service'));
    }

    public function update(Request $request, Service $service)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'points_cost' => ['required', 'integer', 'min:0'],
            'image' => ['nullable', 'image', 'max:2048'],
            'url_pattern' => ['nullable', 'string', 'max:255'],
            'file_id_pattern' => ['nullable', 'string', 'max:255'],
            'expected_url_format' => ['nullable', 'string', 'max:255'],
        ]);

        try {
            // Validate regex patterns if provided
            if (!empty($validated['url_pattern'])) {
                $this->validateRegexPattern($validated['url_pattern']);
            }
            if (!empty($validated['file_id_pattern'])) {
                $this->validateRegexPattern($validated['file_id_pattern']);
            }

            $data = [
                'name' => $validated['name'],
                'description' => $validated['description'],
                'points_cost' => $validated['points_cost'],
                'is_active' => $request->has('is_active'),
                'url_pattern' => $validated['url_pattern'],
                'file_id_pattern' => $validated['file_id_pattern'],
                'expected_url_format' => $validated['expected_url_format'],
            ];

            if ($request->hasFile('image')) {
                // Delete old image if exists
                $service->deleteImage();
                
                // Store new image
                $data['image_path'] = $request->file('image')->store('services', 'public');
            }

            $service->update($data);

            return redirect()
                ->route('admin.services.index')
                ->with('success', 'Service updated successfully');
        } catch (\Exception $e) {
            return back()
                ->withInput()
                ->withErrors(['error' => 'Failed to update service: ' . $e->getMessage()]);
        }
    }

    public function destroy(Service $service)
    {
        try {
            // Delete the image if exists
            $service->deleteImage();
            
            $service->delete();
            return redirect()
                ->route('admin.services.index')
                ->with('success', 'Service deleted successfully');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Failed to delete service: ' . $e->getMessage()]);
        }
    }

    private function validateRegexPattern($pattern)
    {
        try {
            // Remove leading and trailing slashes if they exist
            $pattern = trim($pattern, '/');
            
            // Add delimiters and test the pattern
            if (@preg_match('/' . preg_quote($pattern, '/') . '/', '') === false) {
                throw new \Exception(preg_last_error_msg());
            }
        } catch (\Exception $e) {
            throw new \Exception('Invalid regular expression pattern: ' . $e->getMessage());
        }
    }
}
