<?php

namespace App\Services;

use App\Models\CachedFile;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DownloadService
{
    private $apiKey;
    
    public function __construct()
    {
        $this->apiKey = config('services.gfxload.api_key');
    }

    public function processDownload($url, $serviceId, $fileId)
    {
        Log::info('Processing download:', [
            'url' => $url,
            'service_id' => $serviceId,
            'file_id' => $fileId
        ]);

        // Check if file is already cached
        $cachedFile = CachedFile::findByServiceAndFileId($serviceId, $fileId);
        if ($cachedFile) {
            Log::info('File found in cache', ['cached_file' => $cachedFile->id]);
            $cachedFile->updateLastAccessed();
            return $this->streamCachedFile($cachedFile);
        }

        // Get download method from settings
        $method = Setting::get('download_method', 'method1');
        Log::info('Using download method:', ['method' => $method]);

        try {
            // Process download based on method
            return $method === 'method1' 
                ? $this->processMethodOne($url, $serviceId, $fileId)
                : $this->processMethodTwo($url, $serviceId, $fileId);
        } catch (\Exception $e) {
            Log::error('Download processing failed:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    private function processMethodOne($url, $serviceId, $fileId)
    {
        Log::info('Using Method 1 for download', ['url' => $url]);

        $response = Http::get("http://owner.test/unpub.php", [
            'api' => $this->apiKey,
            'url' => $url
        ]);

        if (!$response->successful()) {
            Log::error('Method 1 download failed', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);
            throw new \Exception('Failed to download file: ' . $response->body());
        }

        $data = $response->json();
        Log::info('Method 1 download successful', ['response_data' => $data]);

        // Download and cache the file
        return $this->downloadAndCacheFile(
            $data['downloadURL'], 
            $data['filename'], 
            $data['filesizeinbytes'], 
            $serviceId, 
            $fileId
        );
    }

    private function processMethodTwo($url, $serviceId, $fileId)
    {
        Log::info('Using Method 2 for download', ['url' => $url]);

        // Step 1: Place order
        $orderResponse = Http::get("https://web.gfxload.com/order", [
            'apikey' => $this->apiKey,
            'url' => $url
        ]);

        if (!$orderResponse->successful()) {
            Log::error('Method 2 order placement failed', [
                'status' => $orderResponse->status(),
                'body' => $orderResponse->body()
            ]);
            throw new \Exception('Failed to place order: ' . $orderResponse->body());
        }

        $orderData = $orderResponse->json();
        $orderId = $orderData['orderid'];
        Log::info('Order placed successfully', ['order_id' => $orderId]);

        // Step 2: Download file
        $downloadResponse = Http::get("https://web.gfxload.com/download", [
            'apikey' => $this->apiKey,
            'orderid' => $orderId
        ]);

        if (!$downloadResponse->successful()) {
            Log::error('Method 2 download failed', [
                'status' => $downloadResponse->status(),
                'body' => $downloadResponse->body()
            ]);
            throw new \Exception('Failed to download file: ' . $downloadResponse->body());
        }

        $data = $downloadResponse->json();
        Log::info('Method 2 download successful', ['response_data' => $data]);

        // Download and cache the file
        return $this->downloadAndCacheFile(
            $data['downloadURL'], 
            $data['filename'], 
            $data['filesizeinbytes'], 
            $serviceId, 
            $fileId
        );
    }

    private function downloadAndCacheFile($downloadUrl, $filename, $fileSize, $serviceId, $fileId)
    {
        Log::info('Downloading and caching file', [
            'url' => $downloadUrl,
            'filename' => $filename,
            'size' => $fileSize
        ]);

        try {
            // Generate unique filename
            $storedFilename = Str::random(40) . '_' . $filename;
            $path = 'downloads/' . $storedFilename;

            // Download and store the file
            $stream = fopen($downloadUrl, 'rb');
            Storage::put($path, $stream);
            if (is_resource($stream)) {
                fclose($stream);
            }

            // Create cache record
            $cachedFile = CachedFile::create([
                'service_id' => $serviceId,
                'file_id' => $fileId,
                'original_filename' => $filename,
                'stored_filename' => $storedFilename,
                'file_size' => $fileSize,
                'path' => $path,
                'last_accessed_at' => now()
            ]);

            Log::info('File cached successfully', [
                'cached_file' => $cachedFile->id,
                'path' => $path
            ]);

            return $this->streamCachedFile($cachedFile);
        } catch (\Exception $e) {
            Log::error('Failed to cache file:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            throw new \Exception('Failed to cache downloaded file: ' . $e->getMessage());
        }
    }

    private function streamCachedFile(CachedFile $cachedFile)
    {
        if (!Storage::exists($cachedFile->path)) {
            Log::error('Cached file not found:', [
                'cached_file' => $cachedFile->id,
                'path' => $cachedFile->path
            ]);
            throw new \Exception('Cached file not found in storage');
        }

        Log::info('Streaming cached file', [
            'cached_file' => $cachedFile->id,
            'path' => $cachedFile->path
        ]);

        return Storage::download(
            $cachedFile->path, 
            $cachedFile->original_filename
        );
    }
}
