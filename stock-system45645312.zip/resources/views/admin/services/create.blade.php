<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Create Service') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="POST" action="{{ route('admin.services.store') }}" class="space-y-6" enctype="multipart/form-data">
                        @csrf

                        <div>
                            <x-input-label for="name" :value="__('Service Name')" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" required autofocus />
                            <x-input-error class="mt-2" :messages="$errors->get('name')" />
                        </div>

                        <div>
                            <x-input-label for="description" :value="__('Description')" />
                            <textarea id="description" name="description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" required></textarea>
                            <x-input-error class="mt-2" :messages="$errors->get('description')" />
                        </div>

                        <div>
                            <x-input-label for="points_cost" :value="__('Points Cost')" />
                            <x-text-input id="points_cost" name="points_cost" type="number" min="0" class="mt-1 block w-full" required />
                            <x-input-error class="mt-2" :messages="$errors->get('points_cost')" />
                        </div>

                        <div>
                            <x-input-label for="image" :value="__('Service Image')" />
                            <input type="file" id="image" name="image" accept="image/*" class="mt-1 block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-md file:border-0
                                file:text-sm file:font-semibold
                                file:bg-blue-50 file:text-blue-700
                                hover:file:bg-blue-100
                            "/>
                            <p class="mt-1 text-sm text-gray-500">
                                PNG, JPG, GIF up to 2MB
                            </p>
                            <x-input-error class="mt-2" :messages="$errors->get('image')" />
                        </div>

                        <div>
                            <x-input-label for="url_pattern" :value="__('URL Pattern (Regex)')" />
                            <x-text-input id="url_pattern" name="url_pattern" type="text" class="mt-1 block w-full" :value="old('url_pattern')" placeholder="https?:\/\/([^\/]+)" />
                            <p class="mt-1 text-sm text-gray-500">{{ __('Enter the pattern without delimiters (no leading/trailing /). Example: https?:\/\/([^\/]+) for matching http or https URLs.') }}</p>
                            <x-input-error class="mt-2" :messages="$errors->get('url_pattern')" />
                        </div>

                        <div>
                            <x-input-label for="file_id_pattern" :value="__('File ID Pattern (Regex)')" />
                            <x-text-input id="file_id_pattern" name="file_id_pattern" type="text" class="mt-1 block w-full" :value="old('file_id_pattern')" placeholder="\/file\/([a-zA-Z0-9]+)" />
                            <p class="mt-1 text-sm text-gray-500">{{ __('Enter the pattern without delimiters. Use capturing groups () to specify the ID part. Example: \/file\/([a-zA-Z0-9]+)') }}</p>
                            <x-input-error class="mt-2" :messages="$errors->get('file_id_pattern')" />
                        </div>

                        <div>
                            <x-input-label for="expected_url_format" :value="__('Expected URL Format')" />
                            <x-text-input id="expected_url_format" name="expected_url_format" type="text" class="mt-1 block w-full" :value="old('expected_url_format')" placeholder="https://example.com/file/abc123" />
                            <p class="mt-1 text-sm text-gray-500">{{ __('Example of the expected URL format to help users.') }}</p>
                            <x-input-error class="mt-2" :messages="$errors->get('expected_url_format')" />
                        </div>

                        <div class="flex items-center">
                            <input id="is_active" name="is_active" type="checkbox" class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-blue-500" checked>
                            <label for="is_active" class="ml-2 block text-sm text-gray-900">Active</label>
                        </div>

                        <div class="flex items-center justify-end">
                            <a href="{{ route('admin.services.index') }}" class="text-gray-600 hover:text-gray-900">Cancel</a>
                            <x-primary-button class="ml-4">
                                {{ __('Create Service') }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
