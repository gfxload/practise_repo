<div x-data="{ 
    urls: [{ url: '', loading: false, error: null, service: null, file_id: null }],
    totalPoints: 0,

    async validateUrl(index) {
        const urlObj = this.urls[index];
        if (!urlObj.url) return;
        
        urlObj.loading = true;
        urlObj.error = null;
        urlObj.service = null;
        urlObj.file_id = null;
        this.calculateTotalPoints();

        try {
            const response = await fetch('/validate-url', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                },
                body: JSON.stringify({ url: urlObj.url })
            });

            const data = await response.json();

            if (data.success) {
                urlObj.service = data.data.service;
                urlObj.file_id = data.data.file_id;
                urlObj.error = null;
            } else {
                urlObj.error = data.message || 'Invalid URL format';
                urlObj.service = null;
                urlObj.file_id = null;
            }
        } catch (e) {
            urlObj.error = 'An error occurred while validating the URL';
            urlObj.service = null;
            urlObj.file_id = null;
        } finally {
            urlObj.loading = false;
            this.calculateTotalPoints();
        }
    },

    addNewUrl() {
        this.urls.push({ url: '', loading: false, error: null, service: null, file_id: null });
    },

    removeUrl(index) {
        if (this.urls.length > 1) {
            this.urls.splice(index, 1);
            this.calculateTotalPoints();
        }
    },

    calculateTotalPoints() {
        this.totalPoints = this.urls.reduce((total, urlObj) => {
            return total + (urlObj.service ? urlObj.service.points_cost : 0);
        }, 0);
    },

    isValid() {
        return this.urls.every(urlObj => urlObj.url && urlObj.service && urlObj.file_id && !urlObj.error);
    }
}">
    <div class="space-y-6">
        <!-- URLs Container -->
        <div class="space-y-4">
            <template x-for="(urlObj, index) in urls" :key="index">
                <div class="border rounded-lg p-4 bg-white shadow-sm">
                    <!-- URL Input Field -->
                    <div class="relative">
                        <div class="flex items-center justify-between mb-2">
                            <label :for="'url-' + index" class="block text-sm font-medium text-gray-700">
                                رابط التحميل #<span x-text="index + 1"></span>
                            </label>
                            <button type="button" 
                                    @click="removeUrl(index)"
                                    x-show="urls.length > 1"
                                    class="text-red-600 hover:text-red-800 text-sm">
                                Remove
                            </button>
                        </div>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <input type="url" 
                                   :name="'urls[' + index + '][url]'"
                                   :id="'url-' + index"
                                   x-model="urlObj.url"
                                   @input.debounce.500ms="validateUrl(index)"
                                   class="block w-full pr-10 border-gray-300 focus:ring-indigo-500 focus:border-indigo-500 rounded-md sm:text-sm"
                                   placeholder="أدخل رابط التحميل هنا"
                                   required>
                            
                            <!-- Loading Indicator -->
                            <div x-show="urlObj.loading" 
                                 class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <svg class="animate-spin h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            </div>

                            <!-- Success Indicator -->
                            <div x-show="urlObj.service && !urlObj.loading" 
                                 class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </div>

                        <!-- Error Message -->
                        <div x-show="urlObj.error" 
                             x-text="urlObj.error"
                             class="mt-2 text-sm text-red-600"
                             role="alert">
                        </div>

                        <!-- Service Information -->
                        <div x-show="urlObj.service" 
                             class="mt-4 rounded-md bg-blue-50 p-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3 flex-1">
                                    <h3 class="text-sm font-medium text-blue-800">الخدمة المكتشفة</h3>
                                    <div class="mt-2 text-sm text-blue-700">
                                        <p class="flex justify-between">
                                            <span>الخدمة:</span>
                                            <span x-text="urlObj.service.name" class="font-medium"></span>
                                        </p>
                                        <p class="flex justify-between mt-1">
                                            <span>التكلفة:</span>
                                            <span x-text="urlObj.service.points_cost + ' نقطة'" class="font-medium"></span>
                                        </p>
                                        <p class="flex justify-between mt-1">
                                            <span>معرف الملف:</span>
                                            <span x-text="urlObj.file_id" class="font-medium"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <!-- Hidden inputs for form submission -->
                            <input type="hidden" :name="'urls[' + index + '][service_id]'" x-model="urlObj.service.id">
                            <input type="hidden" :name="'urls[' + index + '][file_id]'" x-model="urlObj.file_id">
                        </div>
                    </div>
                </div>
            </template>
        </div>

        <!-- Add More Button -->
        <div class="flex justify-center">
            <button type="button" 
                    @click="addNewUrl"
                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                <svg class="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                </svg>
                أضف رابط تحميل آخر
            </button>
        </div>

        <!-- Total Points Summary -->
        <div x-show="totalPoints > 0" class="mt-6 p-4 bg-gray-50 rounded-lg border">
            <div class="flex justify-between items-center">
                <span class="text-sm font-medium text-gray-700">إجمالي النقاط المطلوبة:</span>
                <span class="text-lg font-semibold text-gray-900" x-text="totalPoints + ' نقطة'"></span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH I:\Subscription-management\sys\stock-system\resources\views/components/url-validator.blade.php ENDPATH**/ ?>