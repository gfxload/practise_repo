<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('New Download')); ?>

            </h2>
            <a href="<?php echo e(route('downloads.index')); ?>" class="text-blue-600 hover:text-blue-900">
                <?php echo e(__('← Back to Downloads')); ?>

            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Points Balance Card -->
            <div class="mb-6 bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Points Balance')); ?></h3>
                            <p class="mt-1 text-sm text-gray-600">
                                <?php echo e(__('Your current points balance:')); ?>

                                <span class="font-semibold text-lg"><?php echo e(Auth::user()->points); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Download Form Card -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Add New Download')); ?></h3>
                        <p class="mt-1 text-sm text-gray-600">
                            <?php echo e(__('Paste your download URL and the service will be automatically detected')); ?>

                        </p>
                    </div>

                    <?php if(session('error')): ?>
                        <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('downloads.store')); ?>" class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginal32a5289fe4f2c05723e971847f6457ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32a5289fe4f2c05723e971847f6457ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.url-validator','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('url-validator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32a5289fe4f2c05723e971847f6457ec)): ?>
<?php $attributes = $__attributesOriginal32a5289fe4f2c05723e971847f6457ec; ?>
<?php unset($__attributesOriginal32a5289fe4f2c05723e971847f6457ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32a5289fe4f2c05723e971847f6457ec)): ?>
<?php $component = $__componentOriginal32a5289fe4f2c05723e971847f6457ec; ?>
<?php unset($__componentOriginal32a5289fe4f2c05723e971847f6457ec); ?>
<?php endif; ?>

                        <!-- Supported Services -->
                        <div class="mt-6 border-t pt-6">
                            <h4 class="text-sm font-medium text-gray-900 mb-3"><?php echo e(__('Supported Services')); ?></h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                <?php $__currentLoopData = App\Models\Service::active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-4 border rounded-lg">
                                        <?php if($service->image_path): ?>
                                            <img src="<?php echo e($service->image_url); ?>" alt="<?php echo e($service->name); ?>" class="h-8 mb-2">
                                        <?php endif; ?>
                                        <h5 class="font-medium"><?php echo e($service->name); ?></h5>
                                        <p class="text-sm text-gray-600"><?php echo e($service->points_cost); ?> points</p>
                                        <?php if($service->expected_url_format): ?>
                                            <p class="text-xs text-gray-500 mt-1">
                                                Example: <?php echo e($service->expected_url_format); ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="flex items-center justify-end mt-6 pt-6 border-t border-gray-200">
                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <?php echo e(__('Start Download')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH I:\Subscription-management\sys\stock-system\resources\views/downloads/create.blade.php ENDPATH**/ ?>